import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container10">
      <Helmet>
        <title>Far Flung Apt Pig</title>
        <meta property="og:title" content="Far Flung Apt Pig" />
      </Helmet>
      <span className="home-text10">RECP</span>
      <div className="home-container11">
        <div className="home-container12">
          <span className="home-text11">Find a pattern</span>
          <div className="home-container13">
            <input
              type="text"
              placeholder="Pattern's name"
              id="InputPatternName"
              name="InputPatternName"
              className="home-textinput input"
            />
            <button
              type="button"
              id="bSearchPattern"
              name="bSearchPattern"
              className="button"
            >
              Search
            </button>
          </div>
        </div>
        <div className="home-container14">
          <span className="home-text12">Operation to do</span>
          <div className="home-container15">
            <div className="home-container16">
              <div className="home-container17">
                <div className="home-container18">
                  <div className="home-container19">
                    <div className="home-container20">
                      <div className="home-container21">
                        <div className="home-container22">
                          <div className="home-container23">
                            <div className="home-container24">
                              <input
                                type="checkbox"
                                checked="true"
                                value="Search"
                                name="cbSearchOperation"
                                id="cbSearchOperation"
                                autoComplete="Search"
                                className="home-checkbox1"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <span className="home-text13">Search</span>
                  </div>
                  <input
                    type="checkbox"
                    checked="true"
                    value="Search"
                    name="cbUpdateOperation"
                    id="cbUpdateOperation"
                    autoComplete="Search"
                    className="home-checkbox2"
                  />
                </div>
                <span className="home-text14">Update</span>
              </div>
              <input
                type="checkbox"
                checked="true"
                value="Search"
                name="cbDeleteOperation"
                id="cbDeleteOperation"
                autoComplete="Search"
                className="home-checkbox3"
              />
            </div>
            <span className="home-text15">Delete</span>
          </div>
          <div className="home-container25">
            <div className="home-container26"></div>
          </div>
        </div>
      </div>
      <div className="home-container27">
        <div className="home-container28">
          <span className="home-text16">Name:</span>
          <span id="textPatternName" className="home-text17">
            variablePatternName
          </span>
        </div>
        <div className="home-container29">
          <span className="home-text18">Problem to solve:</span>
          <span id="textPatternProblem" className="home-text19">
            variablePatternProblemToResolve
          </span>
        </div>
        <span className="home-text20">Generic Model</span>
        <img
          src="https://play.teleporthq.io/static/svg/default-img.svg"
          alt="image"
          id="ImgPatternGenericModel"
          className="home-image1"
        />
        <span className="home-text21">Illustration Model</span>
        <img
          src="https://play.teleporthq.io/static/svg/default-img.svg"
          alt="image"
          id="ImgPatternIllustrationMod"
          className="home-image2"
        />
      </div>
    </div>
  )
}

export default Home
